"use strict";

/**
 * Composante : Panneau latérale
 */
class Panel {
  /**
   * Construit un panneau
   * @param {HTMLElement} host Élément hôte qui acceuil le panneau
   * @param {String} bgColor Couleur de fond du panneau (par défaut : gris)
   */
  constructor(host, bgColor = "gray") {
    /**
     * Création de la div contenant le panneau
     */
    let elPanel = document.createElement("div");
    elPanel.id = "mySidebar";
    elPanel.className = "w3-sidebar w3-bar-block w3-animate-left";
    elPanel.style.display = "none";

    this._backgroundColor = bgColor;
    elPanel.style.backgroundColor = this.backgroundColor;

    this.elPanel = elPanel;

    host.appendChild(elPanel);

    /**
     * Création des liens du menu (à configurer)
     */
    for (let i = 0; i < 3; ++i) {
      let elA = document.createElement("a");
      elA.href = "#";
      elA.className = "w3-bar-item w3-button";
      elA.innerHTML = "Link " + (i + 1);

      elPanel.appendChild(elA);
    }

    /**
     * Création du boutton pour fermer le panneau
     */
    let elButton = document.createElement("button");
    elButton.innerHTML = "Close";
    elButton.className = "w3-bar-item w3-button w3-large";

    elPanel.appendChild(elButton);

    // Fermeture du panneau quand on clique sur le boutton close
    elButton.addEventListener("click", () => {
      this.close();
    });
  }

  /**
   * Retourne la valeur de la couleur de fond du panel
   */
  get backgroundColor() {
    return this._backgroundColor;
  }

  /**
   * Change la couleur du fond du panneau
   * @param {string} color Couleur du background du paneau
   */
  set backgroundColor(color = "gray") {
    this._backgroundColor = color;
    this.elPanel.style.backgroundColor = this.backgroundColor;
  }

  /**
   * Ouverture du panneau
   */
  open() {
    this.elPanel.style.display = "block";
  }

  /**
   * Fermeture du panneau
   */
  close() {
    this.elPanel.style.display = "none";
  }
}
